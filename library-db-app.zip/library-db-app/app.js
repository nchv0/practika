process.env.NODE_ENV = 'development';
const express = require('express');
const { initializeDatabase } = require('./db');

// Импорт маршрутов
const authRoutes = require('./routes/auth');
const protectedRoutes = require('./routes/protected');
const bookRoutes = require('./routes/books');
const authorRoutes = require('./routes/authors');
const categoryRoutes = require('./routes/categories');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());

// Инициализация базы данных при запуске
initializeDatabase();

// Основной маршрут с красивым JSON
app.get('/', (req, res) => {
  const response = {
    message: "🚀 API системы библиотеки с аутентификацией",
    version: "2.0.0",
    endpoints: {
      auth: {
        "POST /api/auth/register": "Регистрация нового пользователя",
        "POST /api/auth/login": "Вход в систему (получение JWT токена)"
      },
      protected: {
        "GET /api/protected/profile": "Профиль пользователя (требуется JWT токен)",
        "GET /api/protected/admin": "Админ панель (требуется роль admin)",
        "GET /api/protected/books": "Защищенные операции с книгами"
      },
      books: {
        "GET /api/books": "Получить список книг с пагинацией",
        "GET /api/books/:id": "Получить книгу по ID",
        "POST /api/books": "Создать новую книгу (требуется роль admin)",
        "PUT /api/books/:id": "Обновить книгу (требуется роль admin)",
        "DELETE /api/books/:id": "Удалить книгу (требуется роль admin)"
      },
      authors: {
        "GET /api/authors": "Получить список авторов",
        "GET /api/authors/:id": "Получить автора с его книгами",
        "POST /api/authors": "Создать нового автора (требуется роль admin)"
      },
      categories: {
        "GET /api/categories": "Получить список категорий",
        "POST /api/categories": "Создать новую категорию (требуется роль admin)"
      }
    },
    test_users: {
      admin: {
        email: "admin@library.com",
        password: "admin123",
        role: "admin"
      },
      user: {
        email: "user@library.com", 
        password: "user123",
        role: "user"
      }
    },
    instructions: {
      authentication: "Используйте Authorization: Bearer <JWT_TOKEN> в заголовках",
      pagination: "Используйте ?page=1&limit=10 для пагинации"
    }
  };
  
  // Отправляем красиво отформатированный JSON
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.json(response);
});

// Подключение маршрутов
app.use('/api/auth', authRoutes);
app.use('/api/protected', protectedRoutes);
app.use('/api/books', bookRoutes);
app.use('/api/authors', authorRoutes);
app.use('/api/categories', categoryRoutes);

// Обработка несуществующих маршрутов
app.use('*', (req, res) => {
  res.status(404).json({ 
    error: 'Маршрут не найден',
    available_routes: ['/api/auth', '/api/protected', '/api/books', '/api/authors', '/api/categories']
  });
});

// Обработка ошибок
app.use((error, req, res, next) => {
  console.error('Server Error:', error);
  res.status(500).json({ 
    error: 'Внутренняя ошибка сервера',
    message: error.message 
  });
});

// Запуск сервера
app.listen(PORT, () => {
  console.log('='.repeat(60));
  console.log('🚀 Сервер успешно запущен!');
  console.log('='.repeat(60));
  console.log(`📍 Адрес: http://localhost:${PORT}`);
  console.log(`📚 Система управления библиотекой с аутентификацией`);
  console.log('='.repeat(60));
  console.log('👤 Тестовые пользователи:');
  console.log('   Admin: admin@library.com / admin123');
  console.log('   User:  user@library.com / user123');
  console.log('='.repeat(60));
});