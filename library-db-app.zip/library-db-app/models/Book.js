const { knexConfig } = require('../db');

class Book {
  // Поиск всех книг с пагинацией
  static async findAll(page = 1, limit = 10) {
    try {
      const offset = (page - 1) * limit;
      
      const books = await knexConfig('books')
        .select(
          'books.*',
          'authors.name as author_name',
          'categories.name as category_name'
        )
        .leftJoin('authors', 'books.author_id', 'authors.id')
        .leftJoin('categories', 'books.category_id', 'categories.id')
        .limit(limit)
        .offset(offset)
        .orderBy('books.created_at', 'desc');
      
      const totalCount = await knexConfig('books').count('id as count').first();
      
      return {
        books,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: totalCount['count(*)'],
          totalPages: Math.ceil(totalCount['count(*)'] / limit)
        }
      };
    } catch (error) {
      throw new Error(`Ошибка при получении книг: ${error.message}`);
    }
  }

  // Поиск книги по ID
  static async findById(id) {
    try {
      const book = await knexConfig('books')
        .select(
          'books.*',
          'authors.name as author_name',
          'authors.bio as author_bio',
          'categories.name as category_name',
          'categories.description as category_description'
        )
        .leftJoin('authors', 'books.author_id', 'authors.id')
        .leftJoin('categories', 'books.category_id', 'categories.id')
        .where('books.id', id)
        .first();
      
      if (!book) {
        throw new Error('Книга не найдена');
      }
      
      return book;
    } catch (error) {
      throw new Error(`Ошибка при поиске книги: ${error.message}`);
    }
  }

  // Создание новой книги
  static async create(bookData) {
    try {
      const [id] = await knexConfig('books').insert(bookData);
      return await this.findById(id);
    } catch (error) {
      throw new Error(`Ошибка при создании книги: ${error.message}`);
    }
  }

  // Обновление книги
  static async update(id, bookData) {
    try {
      const updated = await knexConfig('books')
        .where('id', id)
        .update(bookData);
      
      if (!updated) {
        throw new Error('Книга не найдена');
      }
      
      return await this.findById(id);
    } catch (error) {
      throw new Error(`Ошибка при обновлении книги: ${error.message}`);
    }
  }

  // Удаление книги
  static async delete(id) {
    try {
      const deleted = await knexConfig('books')
        .where('id', id)
        .del();
      
      if (!deleted) {
        throw new Error('Книга не найдена');
      }
      
      return { message: 'Книга успешно удалена' };
    } catch (error) {
      throw new Error(`Ошибка при удалении книги: ${error.message}`);
    }
  }
}

module.exports = Book;