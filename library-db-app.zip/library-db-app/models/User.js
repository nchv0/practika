const { knexConfig } = require('../db');
const bcrypt = require('bcryptjs');

class User {
  // Создание пользователя с хешированием пароля
  static async create(userData) {
    try {
      const { email, password, role = 'user' } = userData;
      
      // Проверяем, существует ли пользователь с таким email
      const existingUser = await knexConfig('users')
        .where('email', email)
        .first();
      
      if (existingUser) {
        throw new Error('Пользователь с таким email уже существует');
      }
      
      // Хешируем пароль
      const saltRounds = 10;
      const password_hash = await bcrypt.hash(password, saltRounds);
      
      // Создаем пользователя
      const [id] = await knexConfig('users').insert({
        email,
        password_hash,
        role
      });
      
      // Возвращаем пользователя без пароля
      const user = await knexConfig('users')
        .select('id', 'email', 'role', 'created_at', 'updated_at')
        .where('id', id)
        .first();
      
      return user;
    } catch (error) {
      throw new Error(`Ошибка при создании пользователя: ${error.message}`);
    }
  }

  // Поиск пользователя по email
  static async findByEmail(email) {
    try {
      const user = await knexConfig('users')
        .where('email', email)
        .first();
      
      return user;
    } catch (error) {
      throw new Error(`Ошибка при поиске пользователя: ${error.message}`);
    }
  }

  // Поиск пользователя по ID
  static async findById(id) {
    try {
      const user = await knexConfig('users')
        .select('id', 'email', 'role', 'created_at', 'updated_at')
        .where('id', id)
        .first();
      
      return user;
    } catch (error) {
      throw new Error(`Ошибка при поиске пользователя: ${error.message}`);
    }
  }

  // Проверка пароля
  static async verifyPassword(plainPassword, hashedPassword) {
    try {
      return await bcrypt.compare(plainPassword, hashedPassword);
    } catch (error) {
      throw new Error(`Ошибка при проверке пароля: ${error.message}`);
    }
  }

  // Обновление данных пользователя
  static async update(id, userData) {
    try {
      const updateData = { ...userData };
      
      // Если обновляется пароль - хешируем его
      if (updateData.password) {
        const saltRounds = 10;
        updateData.password_hash = await bcrypt.hash(updateData.password, saltRounds);
        delete updateData.password;
      }
      
      const updated = await knexConfig('users')
        .where('id', id)
        .update(updateData);
      
      if (!updated) {
        throw new Error('Пользователь не найден');
      }
      
      return await this.findById(id);
    } catch (error) {
      throw new Error(`Ошибка при обновлении пользователя: ${error.message}`);
    }
  }
}

module.exports = User;