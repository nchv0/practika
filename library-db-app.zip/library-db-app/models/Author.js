const { knexConfig } = require('../db');

class Author {
  // Получение списка авторов
  static async findAll() {
    try {
      const authors = await knexConfig('authors')
        .select('*')
        .orderBy('name');
      
      return authors;
    } catch (error) {
      throw new Error(`Ошибка при получении авторов: ${error.message}`);
    }
  }

  // Получение автора с его книгами
  static async findByIdWithBooks(id) {
    try {
      const author = await knexConfig('authors')
        .where('authors.id', id)
        .first();
      
      if (!author) {
        throw new Error('Автор не найден');
      }
      
      const books = await knexConfig('books')
        .select(
          'books.*',
          'categories.name as category_name'
        )
        .leftJoin('categories', 'books.category_id', 'categories.id')
        .where('books.author_id', id)
        .orderBy('books.title');
      
      return {
        ...author,
        books
      };
    } catch (error) {
      throw new Error(`Ошибка при поиске автора: ${error.message}`);
    }
  }

  // Создание нового автора
  static async create(authorData) {
    try {
      const [id] = await knexConfig('authors').insert(authorData);
      
      const author = await knexConfig('authors')
        .where('id', id)
        .first();
      
      return author;
    } catch (error) {
      throw new Error(`Ошибка при создании автора: ${error.message}`);
    }
  }
}

module.exports = Author;