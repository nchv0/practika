const { knexConfig } = require('../db');

class Category {
  static async findAll() {
    try {
      const categories = await knexConfig('categories')
        .select('*')
        .orderBy('name');
      
      return categories;
    } catch (error) {
      throw new Error(`Ошибка при получении категорий: ${error.message}`);
    }
  }

  static async create(categoryData) {
    try {
      const [id] = await knexConfig('categories').insert(categoryData);
      
      const category = await knexConfig('categories')
        .where('id', id)
        .first();
      
      return category;
    } catch (error) {
      throw new Error(`Ошибка при создании категории: ${error.message}`);
    }
  }
}

module.exports = Category;