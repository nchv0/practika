const axios = require('axios');

const BASE_URL = 'http://localhost:3000/api';

async function testAuth() {
  console.log('🧪 Тестирование системы аутентификации...\n');

  try {
    // 1. Регистрация нового пользователя
    console.log('1. Тестирование регистрации:');
    const registerResponse = await axios.post(`${BASE_URL}/auth/register`, {
      email: 'newuser@test.com',
      password: 'password123',
      role: 'user'
    });
    console.log('✅ Регистрация успешна:', registerResponse.data.message);
    console.log('Токен:', registerResponse.data.token.substring(0, 50) + '...\n');

    const token = registerResponse.data.token;

    // 2. Вход в систему
    console.log('2. Тестирование входа:');
    const loginResponse = await axios.post(`${BASE_URL}/auth/login`, {
      email: 'newuser@test.com',
      password: 'password123'
    });
    console.log('✅ Вход успешен:', loginResponse.data.message, '\n');

    // 3. Доступ к защищенному профилю
    console.log('3. Тестирование защищенного профиля:');
    const profileResponse = await axios.get(`${BASE_URL}/protected/profile`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    console.log('✅ Доступ к профилю:', profileResponse.data.message, '\n');

    // 4. Попытка доступа к админке (должна быть ошибка)
    console.log('4. Тестирование доступа к админке (ожидается ошибка):');
    try {
      await axios.get(`${BASE_URL}/protected/admin`, {
        headers: { Authorization: `Bearer ${token}` }
      });
    } catch (error) {
      console.log('✅ Доступ запрещен как и ожидалось:', error.response.data.error, '\n');
    }

    console.log('🎉 Все тесты пройдены успешно!');

  } catch (error) {
    console.error('❌ Ошибка тестирования:', error.response?.data || error.message);
  }
}

testAuth();