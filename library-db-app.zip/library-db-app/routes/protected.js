const express = require('express');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/protected/profile - Профиль пользователя (требуется аутентификация)
router.get('/profile', authenticateToken, (req, res) => {
  res.json({
    message: 'Доступ к защищенному ресурсу разрешен',
    user: req.user
  });
});

// GET /api/protected/admin - Только для администраторов
router.get('/admin', 
  authenticateToken, 
  requireRole(['admin']), 
  (req, res) => {
    res.json({
      message: 'Добро пожаловать в панель администратора',
      user: req.user
    });
  }
);

// GET /api/protected/books - Защищенные операции с книгами
router.get('/books', authenticateToken, (req, res) => {
  res.json({
    message: 'Доступ к книгам разрешен',
    user: req.user,
    books: ['Книга 1', 'Книга 2', 'Книга 3'] // Пример данных
  });
});

// POST /api/protected/books - Создание книг (только для администраторов)
router.post('/books', 
  authenticateToken, 
  requireRole(['admin']), 
  (req, res) => {
    res.json({
      message: 'Книга успешно создана',
      user: req.user,
      book: req.body
    });
  }
);

module.exports = router;