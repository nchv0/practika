const express = require('express');
const Author = require('../models/Author');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/authors - Получение списка авторов
router.get('/', async (req, res) => {
  try {
    const authors = await Author.findAll();
    res.json(authors);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/authors/:id - Получение автора с его книгами
router.get('/:id', async (req, res) => {
  try {
    const author = await Author.findByIdWithBooks(parseInt(req.params.id));
    res.json(author);
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
});

// POST /api/authors - Создание нового автора (требуется аутентификация)
router.post('/', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const author = await Author.create(req.body);
    res.status(201).json(author);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;