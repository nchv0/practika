const express = require('express');
const Category = require('../models/Category');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/categories - Получение списка категорий
router.get('/', async (req, res) => {
  try {
    const categories = await Category.findAll();
    res.json(categories);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/categories - Создание новой категории (требуется аутентификация)
router.post('/', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const category = await Category.create(req.body);
    res.status(201).json(category);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;