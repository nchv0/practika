const express = require('express');
const Book = require('../models/Book');
const { authenticateToken, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/books - Получение списка книг с пагинацией
router.get('/', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    
    const result = await Book.findAll(page, limit);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/books/:id - Получение книги по ID
router.get('/:id', async (req, res) => {
  try {
    const book = await Book.findById(parseInt(req.params.id));
    res.json(book);
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
});

// POST /api/books - Создание новой книги (требуется аутентификация)
router.post('/', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const book = await Book.create(req.body);
    res.status(201).json(book);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// PUT /api/books/:id - Обновление книги (требуется аутентификация)
router.put('/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const book = await Book.update(parseInt(req.params.id), req.body);
    res.json(book);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// DELETE /api/books/:id - Удаление книги (требуется аутентификация)
router.delete('/:id', authenticateToken, requireRole(['admin']), async (req, res) => {
  try {
    const result = await Book.delete(parseInt(req.params.id));
    res.json(result);
  } catch (error) {
    res.status(404).json({ error: error.message });
  }
});

module.exports = router;