const bcrypt = require('bcryptjs');

exports.seed = async function(knex) {
  // Очистка таблицы пользователей
  await knex('users').del();

  // Хеширование паролей
  const saltRounds = 10;
  const adminPassword = await bcrypt.hash('admin123', saltRounds);
  const userPassword = await bcrypt.hash('user123', saltRounds);

  // Добавление тестовых пользователей
  await knex('users').insert([
    {
      email: 'admin@library.com',
      password_hash: adminPassword,
      role: 'admin'
    },
    {
      email: 'user@library.com',
      password_hash: userPassword,
      role: 'user'
    },
    {
      email: 'test@library.com',
      password_hash: userPassword,
      role: 'user'
    }
  ]);

  console.log('✅ Тестовые пользователи успешно добавлены');
};