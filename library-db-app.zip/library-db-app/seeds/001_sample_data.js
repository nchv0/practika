exports.seed = async function(knex) {
  // Очистка таблиц в правильном порядке (из-за внешних ключей)
  await knex('books').del();
  await knex('authors').del();
  await knex('categories').del();

  // Добавление категорий
  const categories = await knex('categories').insert([
    { name: 'Фантастика', description: 'Научная фантастика и фэнтези' },
    { name: 'Детектив', description: 'Детективные романы и триллеры' },
    { name: 'Роман', description: 'Художественная литература' },
    { name: 'Программирование', description: 'Техническая литература по программированию' }
  ]).returning('id');

  // Добавление авторов
  const authors = await knex('authors').insert([
    { name: 'Айзек Азимов', bio: 'Американский писатель-фантаст' },
    { name: 'Агата Кристи', bio: 'Английская писательница детективов' },
    { name: 'Лев Толстой', bio: 'Русский писатель и мыслитель' },
    { name: 'Кайл Симпсон', bio: 'Современный автор книг по программированию' }
  ]).returning('id');

  // Добавление книг
  await knex('books').insert([
    {
      title: 'Основание',
      isbn: '978-5171504108',
      publication_year: 1951,
      author_id: authors[0].id,
      category_id: categories[0].id,
      description: 'Эпическая научно-фантастическая сага'
    },
    {
      title: 'Убийство в Восточном экспрессе',
      isbn: '978-5171504115',
      publication_year: 1934,
      author_id: authors[1].id,
      category_id: categories[1].id,
      description: 'Знаменитый детектив Эркюля Пуаро'
    },
    {
      title: 'Война и мир',
      isbn: '978-5171504122',
      publication_year: 1869,
      author_id: authors[2].id,
      category_id: categories[2].id,
      description: 'Роман-эпопея о русском обществе эпохи Наполеоновских войн'
    },
    {
      title: 'You Don\'t Know JS',
      isbn: '978-5446106470',
      publication_year: 2015,
      author_id: authors[3].id,
      category_id: categories[3].id,
      description: 'Серия книг о глубоком понимании JavaScript'
    },
    {
      title: 'Я, робот',
      isbn: '978-5171504139',
      publication_year: 1950,
      author_id: authors[0].id,
      category_id: categories[0].id,
      description: 'Сборник научно-фантастических рассказов'
    }
  ]);

  console.log('✅ Тестовые данные успешно добавлены');
};