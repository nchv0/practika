const knex = require('knex');

// Настройка подключения к SQLite базе данных
const knexConfig = knex({
  client: 'sqlite3',
  connection: {
    filename: './library.db'
  },
  useNullAsDefault: true,
  pool: {
    afterCreate: (conn, done) => {
      // Включаем поддержку внешних ключей в SQLite
      conn.run('PRAGMA foreign_keys = ON', done);
    }
  }
});

// Функция для инициализации базы данных
async function initializeDatabase() {
  try {
    console.log('🔄 Инициализация SQLite базы данных...');
    
    // Проверяем подключение
    await knexConfig.raw('SELECT 1');
    console.log('✅ База данных SQLite готова к работе');
    
    return true;
  } catch (error) {
    console.error('❌ Ошибка инициализации базы данных:', error.message);
    return false;
  }
}

module.exports = { knexConfig, initializeDatabase };