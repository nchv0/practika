const http = require('http');
const url = require('url');
const querystring = require('querystring');

const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    const method = req.method;
    
    // Устанавливаем заголовки CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    if (method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }
    
    // Маршрутизация
    if (pathname === '/' && method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end('<h1>Главная страница</h1><p>Добро пожаловать на сервер Node.js!</p>');
    }
    else if (pathname === '/about' && method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end('<h1>О нас</h1><p>Информация о нашем проекте</p>');
    }
    else if (pathname === '/api/users' && method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify([
            { id: 1, name: 'Иван', email: 'ivan@example.com' },
            { id: 2, name: 'Мария', email: 'maria@example.com' },
            { id: 3, name: 'Петр', email: 'petr@example.com' }
        ]));
    }
    else if (pathname === '/api/users' && method === 'POST') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            const userData = querystring.parse(body);
            res.writeHead(201, { 'Content-Type': 'application/json; charset=utf-8' });
            res.end(JSON.stringify({
                id: Date.now(),
                name: userData.name,
                email: userData.email,
                message: 'Пользователь создан успешно'
            }));
        });
    }
    else if (pathname.startsWith('/api/users/') && method === 'GET') {
        const userId = pathname.split('/')[3];
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify({
            id: userId,
            name: 'Пользователь ' + userId,
            email: `user${userId}@example.com`
        }));
    }
    else if (pathname === '/api/products' && method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify([
            { id: 1, name: 'Ноутбук', price: 50000 },
            { id: 2, name: 'Смартфон', price: 25000 },
            { id: 3, name: 'Планшет', price: 15000 }
        ]));
    }
    else {
        res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end('<h1>404 - Страница не найдена</h1>');
    }
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Сервер запущен на порту ${PORT}`);
    console.log(`Доступен по адресу: http://localhost:${PORT}`);
});