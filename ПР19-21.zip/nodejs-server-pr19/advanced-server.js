const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3001;

// Middleware для логирования
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.url}`);
    next();
});

// Middleware для обработки CORS
app.use(cors());

// Middleware для парсинга JSON
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Обслуживание статических файлов
app.use(express.static(path.join(__dirname, 'public')));

// Mock база данных
let users = [
    { id: 1, name: 'Иван Иванов', email: 'ivan@example.com', age: 25 },
    { id: 2, name: 'Мария Петрова', email: 'maria@example.com', age: 30 },
    { id: 3, name: 'Петр Сидоров', email: 'petr@example.com', age: 35 }
];

let products = [
    { id: 1, name: 'Ноутбук', price: 50000, category: 'Электроника' },
    { id: 2, name: 'Смартфон', price: 25000, category: 'Электроника' },
    { id: 3, name: 'Книга', price: 500, category: 'Книги' }
];

// Маршруты для пользователей
app.get('/api/users', (req, res) => {
    res.json(users);
});

app.get('/api/users/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    const user = users.find(u => u.id === userId);
    
    if (user) {
        res.json(user);
    } else {
        res.status(404).json({ error: 'Пользователь не найден' });
    }
});

app.post('/api/users', (req, res) => {
    const { name, email, age } = req.body;
    
    if (!name || !email) {
        return res.status(400).json({ error: 'Имя и email обязательны' });
    }
    
    const newUser = {
        id: users.length + 1,
        name,
        email,
        age: age || null
    };
    
    users.push(newUser);
    res.status(201).json(newUser);
});

app.put('/api/users/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
        return res.status(404).json({ error: 'Пользователь не найден' });
    }
    
    const { name, email, age } = req.body;
    users[userIndex] = { ...users[userIndex], name, email, age };
    
    res.json(users[userIndex]);
});

app.delete('/api/users/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    const userIndex = users.findIndex(u => u.id === userId);
    
    if (userIndex === -1) {
        return res.status(404).json({ error: 'Пользователь не найден' });
    }
    
    const deletedUser = users.splice(userIndex, 1)[0];
    res.json({ message: 'Пользователь удален', user: deletedUser });
});

// Маршруты для продуктов
app.get('/api/products', (req, res) => {
    res.json(products);
});

app.get('/api/products/:id', (req, res) => {
    const productId = parseInt(req.params.id);
    const product = products.find(p => p.id === productId);
    
    if (product) {
        res.json(product);
    } else {
        res.status(404).json({ error: 'Продукт не найден' });
    }
});

// Статическая страница
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Обработка 404
app.use((req, res) => {
    res.status(404).json({ error: 'Маршрут не найден' });
});

// Обработка ошибок
app.use((err, req, res, next) => {
    console.error('Ошибка сервера:', err);
    res.status(500).json({ error: 'Внутренняя ошибка сервера' });
});

app.listen(PORT, () => {
    console.log(`Продвинутый сервер запущен на порту ${PORT}`);
    console.log(`Доступен по адресу: http://localhost:${PORT}`);
});