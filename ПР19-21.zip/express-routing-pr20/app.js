const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');

// Импорт роутеров
const usersRouter = require('./routes/users');
const productsRouter = require('./routes/products');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(morgan('dev')); // Более читабельное логирование
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Глобальное middleware для логирования
app.use((req, res, next) => {
    console.log(`📍 ${req.method} ${req.url} - ${new Date().toISOString()}`);
    next();
});

// Базовые маршруты
app.get('/', (req, res) => {
    res.json({
        message: 'Добро пожаловать в Express.js приложение!',
        version: '1.0.0',
        timestamp: new Date().toISOString(),
        endpoints: {
            users: '/api/users',
            products: '/api/products',
            docs: '/api/docs'
        }
    });
});

app.get('/api/docs', (req, res) => {
    res.json({
        documentation: 'API Documentation',
        users: {
            'GET /api/users': 'Получить всех пользователей',
            'GET /api/users/:id': 'Получить пользователя по ID',
            'POST /api/users': 'Создать пользователя',
            'PUT /api/users/:id': 'Обновить пользователя',
            'DELETE /api/users/:id': 'Удалить пользователя',
            'GET /api/users/:id/profile': 'Профиль пользователя'
        },
        products: {
            'GET /api/products': 'Получить все товары',
            'GET /api/products/:id': 'Получить товар по ID',
            'POST /api/products': 'Создать товар',
            'PUT /api/products/:id': 'Обновить товар',
            'DELETE /api/products/:id': 'Удалить товар',
            'GET /api/products/:id/stock': 'Проверить наличие',
            'PATCH /api/products/:id/stock': 'Обновить количество'
        }
    });
});

// Подключение роутеров (БЕЗ middleware валидации для тестирования)
app.use('/api/users', usersRouter);
app.use('/api/products', productsRouter);

// Middleware для обработки 404
app.use((req, res) => {
    res.status(404).json({
        error: 'Маршрут не найден',
        path: req.path,
        method: req.method,
        availableEndpoints: ['/api/users', '/api/products', '/api/docs']
    });
});

// Централизованная обработка ошибок
app.use((err, req, res, next) => {
    console.error('🚨 Ошибка сервера:', err);
    
    // Более подробная информация об ошибке
    res.status(500).json({
        error: 'Внутренняя ошибка сервера',
        message: err.message,
        stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
    });
});

app.listen(PORT, () => {
    console.log(`🚀 Сервер запущен на порту ${PORT}`);
    console.log(`📚 Документация: http://localhost:${PORT}/api/docs`);
    console.log(`👥 Пользователи: http://localhost:${PORT}/api/users`);
    console.log(`🛍️ Товары: http://localhost:${PORT}/api/products`);
    console.log(`🌐 Окружение: ${process.env.NODE_ENV || 'development'}`);
});