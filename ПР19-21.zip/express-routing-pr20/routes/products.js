const express = require('express');
const router = express.Router();

// Mock база данных товаров
let products = [
    { 
        id: 1, 
        name: 'Ноутбук HP Pavilion', 
        price: 50000, 
        category: 'Электроника', 
        description: 'Мощный ноутбук для работы и игр',
        inStock: true,
        stockQuantity: 15,
        tags: ['ноутбук', 'электроника', 'работа']
    },
    { 
        id: 2, 
        name: 'Смартфон Samsung Galaxy', 
        price: 25000, 
        category: 'Электроника', 
        description: 'Современный смартфон с отличной камерой',
        inStock: true,
        stockQuantity: 30,
        tags: ['смартфон', 'электроника', 'android']
    },
    { 
        id: 3, 
        name: 'Книга "JavaScript для профессионалов"', 
        price: 1500, 
        category: 'Книги', 
        description: 'Подробное руководство по JavaScript',
        inStock: true,
        stockQuantity: 25,
        tags: ['книга', 'программирование', 'javascript']
    },
    { 
        id: 4, 
        name: 'Кофеварка', 
        price: 8000, 
        category: 'Бытовая техника', 
        description: 'Автоматическая кофеварка для дома',
        inStock: false,
        stockQuantity: 0,
        tags: ['кофе', 'техника', 'кухня']
    }
];

// Middleware для логирования запросов к товарам
router.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] Products API: ${req.method} ${req.path}`);
    next();
});

// Middleware для поиска товара по ID
router.param('id', (req, res, next, id) => {
    const productId = parseInt(id);
    const product = products.find(p => p.id === productId);
    
    if (!product) {
        return res.status(404).json({ 
            error: 'Товар не найден',
            id: productId 
        });
    }
    
    req.product = product;
    req.productId = productId;
    next();
});

// GET /api/products - Получить все товары
router.get('/', (req, res) => {
    const { category, minPrice, maxPrice, inStock, search, tag } = req.query;
    
    let filteredProducts = [...products];
    
    // Фильтрация по категории
    if (category) {
        filteredProducts = filteredProducts.filter(product =>
            product.category.toLowerCase() === category.toLowerCase()
        );
    }
    
    // Фильтрация по цене
    if (minPrice) {
        filteredProducts = filteredProducts.filter(product => 
            product.price >= parseInt(minPrice)
        );
    }
    
    if (maxPrice) {
        filteredProducts = filteredProducts.filter(product => 
            product.price <= parseInt(maxPrice)
        );
    }
    
    // Фильтрация по наличию
    if (inStock !== undefined) {
        const inStockBool = inStock === 'true';
        filteredProducts = filteredProducts.filter(product => 
            product.inStock === inStockBool
        );
    }
    
    // Поиск по названию и описанию
    if (search) {
        const searchLower = search.toLowerCase();
        filteredProducts = filteredProducts.filter(product =>
            product.name.toLowerCase().includes(searchLower) ||
            product.description.toLowerCase().includes(searchLower)
        );
    }
    
    // Фильтрация по тегу
    if (tag) {
        filteredProducts = filteredProducts.filter(product =>
            product.tags.includes(tag.toLowerCase())
        );
    }
    
    // Сортировка
    const sortBy = req.query.sortBy || 'id';
    const sortOrder = req.query.sortOrder || 'asc';
    
    filteredProducts.sort((a, b) => {
        if (sortOrder === 'asc') {
            return a[sortBy] > b[sortBy] ? 1 : -1;
        } else {
            return a[sortBy] < b[sortBy] ? 1 : -1;
        }
    });
    
    res.json({
        count: filteredProducts.length,
        totalValue: filteredProducts.reduce((sum, product) => sum + product.price, 0),
        products: filteredProducts
    });
});

// GET /api/products/:id - Получить товар по ID
router.get('/:id', (req, res) => {
    res.json(req.product);
});

// POST /api/products - Создать товар
router.post('/', (req, res) => {
    const { name, price, category, description, stockQuantity, tags } = req.body;
    
    // Валидация
    if (!name || !price || !category) {
        return res.status(400).json({
            error: 'Название, цена и категория обязательны для заполнения'
        });
    }
    
    if (price < 0) {
        return res.status(400).json({
            error: 'Цена не может быть отрицательной'
        });
    }
    
    const newProduct = {
        id: products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1,
        name,
        price: parseInt(price),
        category,
        description: description || '',
        inStock: (stockQuantity || 0) > 0,
        stockQuantity: stockQuantity || 0,
        tags: tags || [],
        createdAt: new Date().toISOString()
    };
    
    products.push(newProduct);
    
    res.status(201).json({
        message: 'Товар создан успешно',
        product: newProduct
    });
});

// PUT /api/products/:id - Полное обновление товара
router.put('/:id', (req, res) => {
    const { name, price, category, description, stockQuantity, tags } = req.body;
    const productIndex = products.findIndex(p => p.id === req.productId);
    
    // Валидация
    if (!name || !price || !category) {
        return res.status(400).json({
            error: 'Название, цена и категория обязательны для заполнения'
        });
    }
    
    if (price < 0) {
        return res.status(400).json({
            error: 'Цена не может быть отрицательной'
        });
    }
    
    products[productIndex] = {
        ...products[productIndex],
        name,
        price: parseInt(price),
        category,
        description: description || '',
        inStock: (stockQuantity || 0) > 0,
        stockQuantity: stockQuantity || 0,
        tags: tags || [],
        updatedAt: new Date().toISOString()
    };
    
    res.json({
        message: 'Товар обновлен успешно',
        product: products[productIndex]
    });
});

// PATCH /api/products/:id - Частичное обновление товара
router.patch('/:id', (req, res) => {
    const productIndex = products.findIndex(p => p.id === req.productId);
    const { name, price, category, description, stockQuantity, tags } = req.body;
    
    // Валидация цены
    if (price !== undefined && price < 0) {
        return res.status(400).json({
            error: 'Цена не может быть отрицательной'
        });
    }
    
    products[productIndex] = {
        ...products[productIndex],
        ...(name && { name }),
        ...(price !== undefined && { price: parseInt(price) }),
        ...(category && { category }),
        ...(description !== undefined && { description }),
        ...(stockQuantity !== undefined && { 
            stockQuantity,
            inStock: stockQuantity > 0
        }),
        ...(tags && { tags }),
        updatedAt: new Date().toISOString()
    };
    
    res.json({
        message: 'Товар частично обновлен',
        product: products[productIndex]
    });
});

// DELETE /api/products/:id - Удалить товар
router.delete('/:id', (req, res) => {
    const productIndex = products.findIndex(p => p.id === req.productId);
    const deletedProduct = products.splice(productIndex, 1)[0];
    
    res.json({
        message: 'Товар удален успешно',
        product: deletedProduct
    });
});

// GET /api/products/:id/stock - Проверка наличия товара
router.get('/:id/stock', (req, res) => {
    const product = req.product;
    res.json({
        productId: product.id,
        productName: product.name,
        inStock: product.inStock,
        stockQuantity: product.stockQuantity,
        lastUpdated: product.updatedAt || product.createdAt
    });
});

// PATCH /api/products/:id/stock - Обновление количества товара
router.patch('/:id/stock', (req, res) => {
    const { quantity } = req.body;
    const productIndex = products.findIndex(p => p.id === req.productId);
    
    if (quantity === undefined || quantity < 0) {
        return res.status(400).json({
            error: 'Количество должно быть неотрицательным числом'
        });
    }
    
    products[productIndex].stockQuantity = quantity;
    products[productIndex].inStock = quantity > 0;
    products[productIndex].updatedAt = new Date().toISOString();
    
    res.json({
        message: 'Количество товара обновлено',
        product: {
            id: products[productIndex].id,
            name: products[productIndex].name,
            stockQuantity: products[productIndex].stockQuantity,
            inStock: products[productIndex].inStock
        }
    });
});

module.exports = router;