const express = require('express');
const router = express.Router();

// Mock база данных пользователей
let users = [
    { id: 1, name: 'Иван Иванов', email: 'ivan@example.com', age: 25, role: 'user' },
    { id: 2, name: 'Мария Петрова', email: 'maria@example.com', age: 30, role: 'admin' },
    { id: 3, name: 'Петр Сидоров', email: 'petr@example.com', age: 35, role: 'user' },
    { id: 4, name: 'Анна Козлова', email: 'anna@example.com', age: 28, role: 'moderator' }
];

// Middleware для логирования запросов к пользователям
router.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] Users API: ${req.method} ${req.path}`);
    next();
});

// Middleware для поиска пользователя по ID
router.param('id', (req, res, next, id) => {
    const userId = parseInt(id);
    const user = users.find(u => u.id === userId);
    
    if (!user) {
        return res.status(404).json({ 
            error: 'Пользователь не найден',
            id: userId 
        });
    }
    
    req.user = user;
    req.userId = userId;
    next();
});

// GET /api/users - Получить всех пользователей
router.get('/', (req, res) => {
    const { role, minAge, maxAge, search } = req.query;
    
    let filteredUsers = [...users];
    
    // Фильтрация по роли
    if (role) {
        filteredUsers = filteredUsers.filter(user => 
            user.role.toLowerCase() === role.toLowerCase()
        );
    }
    
    // Фильтрация по возрасту
    if (minAge) {
        filteredUsers = filteredUsers.filter(user => user.age >= parseInt(minAge));
    }
    
    if (maxAge) {
        filteredUsers = filteredUsers.filter(user => user.age <= parseInt(maxAge));
    }
    
    // Поиск по имени
    if (search) {
        filteredUsers = filteredUsers.filter(user =>
            user.name.toLowerCase().includes(search.toLowerCase())
        );
    }
    
    res.json({
        count: filteredUsers.length,
        users: filteredUsers
    });
});

// GET /api/users/:id - Получить пользователя по ID
router.get('/:id', (req, res) => {
    res.json(req.user);
});

// POST /api/users - Создать пользователя
router.post('/', (req, res) => {
    const { name, email, age, role = 'user' } = req.body;
    
    // Валидация
    if (!name || !email) {
        return res.status(400).json({
            error: 'Имя и email обязательны для заполнения'
        });
    }
    
    // Проверка уникальности email
    const existingUser = users.find(u => u.email === email);
    if (existingUser) {
        return res.status(409).json({
            error: 'Пользователь с таким email уже существует'
        });
    }
    
    const newUser = {
        id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1,
        name,
        email,
        age: age || null,
        role,
        createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    
    res.status(201).json({
        message: 'Пользователь создан успешно',
        user: newUser
    });
});

// PUT /api/users/:id - Полное обновление пользователя
router.put('/:id', (req, res) => {
    const { name, email, age, role } = req.body;
    const userIndex = users.findIndex(u => u.id === req.userId);
    
    // Валидация
    if (!name || !email) {
        return res.status(400).json({
            error: 'Имя и email обязательны для заполнения'
        });
    }
    
    // Проверка уникальности email (исключая текущего пользователя)
    const emailExists = users.some(u => u.email === email && u.id !== req.userId);
    if (emailExists) {
        return res.status(409).json({
            error: 'Пользователь с таким email уже существует'
        });
    }
    
    users[userIndex] = {
        ...users[userIndex],
        name,
        email,
        age: age || null,
        role: role || users[userIndex].role,
        updatedAt: new Date().toISOString()
    };
    
    res.json({
        message: 'Пользователь обновлен успешно',
        user: users[userIndex]
    });
});

// PATCH /api/users/:id - Частичное обновление пользователя
router.patch('/:id', (req, res) => {
    const userIndex = users.findIndex(u => u.id === req.userId);
    const { name, email, age, role } = req.body;
    
    // Проверка уникальности email
    if (email) {
        const emailExists = users.some(u => u.email === email && u.id !== req.userId);
        if (emailExists) {
            return res.status(409).json({
                error: 'Пользователь с таким email уже существует'
            });
        }
    }
    
    users[userIndex] = {
        ...users[userIndex],
        ...(name && { name }),
        ...(email && { email }),
        ...(age !== undefined && { age }),
        ...(role && { role }),
        updatedAt: new Date().toISOString()
    };
    
    res.json({
        message: 'Пользователь частично обновлен',
        user: users[userIndex]
    });
});

// DELETE /api/users/:id - Удалить пользователя
router.delete('/:id', (req, res) => {
    const userIndex = users.findIndex(u => u.id === req.userId);
    const deletedUser = users.splice(userIndex, 1)[0];
    
    res.json({
        message: 'Пользователь удален успешно',
        user: deletedUser
    });
});

// GET /api/users/:id/profile - Дополнительный маршрут для профиля
router.get('/:id/profile', (req, res) => {
    const user = req.user;
    res.json({
        profile: {
            id: user.id,
            name: user.name,
            email: user.email,
            age: user.age,
            role: user.role,
            memberSince: user.createdAt || '2024-01-01'
        },
        statistics: {
            orders: Math.floor(Math.random() * 50),
            reviews: Math.floor(Math.random() * 10)
        }
    });
});

module.exports = router;