// Middleware для валидации данных

const validateUser = (req, res, next) => {
    // Пропускаем GET и DELETE запросы
    if (req.method === 'GET' || req.method === 'DELETE') {
        return next();
    }
    
    const { name, email, age } = req.body;
    
    if (!name || !email) {
        return res.status(400).json({
            error: 'Имя и email обязательны для заполнения'
        });
    }
    
    if (name.length < 2) {
        return res.status(400).json({
            error: 'Имя должно содержать минимум 2 символа'
        });
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return res.status(400).json({
            error: 'Некорректный формат email'
        });
    }
    
    if (age && (age < 0 || age > 150)) {
        return res.status(400).json({
            error: 'Возраст должен быть в диапазоне от 0 до 150'
        });
    }
    
    next();
};

const validateProduct = (req, res, next) => {
    // Пропускаем GET и DELETE запросы
    if (req.method === 'GET' || req.method === 'DELETE') {
        return next();
    }
    
    const { name, price, category } = req.body;
    
    if (!name || !price || !category) {
        return res.status(400).json({
            error: 'Название, цена и категория обязательны для заполнения'
        });
    }
    
    if (name.length < 2) {
        return res.status(400).json({
            error: 'Название товара должно содержать минимум 2 символа'
        });
    }
    
    if (price < 0) {
        return res.status(400).json({
            error: 'Цена не может быть отрицательной'
        });
    }
    
    if (category.length < 2) {
        return res.status(400).json({
            error: 'Категория должна содержать минимум 2 символа'
        });
    }
    
    next();
};

module.exports = {
    validateUser,
    validateProduct
};