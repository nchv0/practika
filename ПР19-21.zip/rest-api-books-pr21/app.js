const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(morgan('combined')); // Логирование запросов
app.use(cors()); // CORS
app.use(express.json()); // Парсинг JSON

// Mock база данных книг
let books = [
    {
        id: 1,
        title: "JavaScript: The Good Parts",
        author: "Douglas Crockford",
        isbn: "978-0596517748",
        genre: "Programming",
        year: 2008,
        publisher: "O'Reilly Media",
        pages: 176,
        description: "Most programming languages contain good and bad parts, but JavaScript has more than its share of the bad.",
        inStock: true,
        price: 25.99
    },
    {
        id: 2,
        title: "Clean Code: A Handbook of Agile Software Craftsmanship",
        author: "Robert C. Martin",
        isbn: "978-0132350884",
        genre: "Programming",
        year: 2008,
        publisher: "Prentice Hall",
        pages: 464,
        description: "Even bad code can function. But if code isn't clean, it can bring a development organization to its knees.",
        inStock: true,
        price: 35.99
    },
    {
        id: 3,
        title: "The Great Gatsby",
        author: "F. Scott Fitzgerald",
        isbn: "978-0743273565",
        genre: "Classic",
        year: 1925,
        publisher: "Scribner",
        pages: 180,
        description: "A portrait of the Jazz Age in all of its decadence and excess.",
        inStock: false,
        price: 12.99
    },
    {
        id: 4,
        title: "1984",
        author: "George Orwell",
        isbn: "978-0451524935",
        genre: "Dystopian",
        year: 1949,
        publisher: "Signet Classic",
        pages: 328,
        description: "A dystopian social science fiction novel and cautionary tale.",
        inStock: true,
        price: 9.99
    },
    {
        id: 5,
        title: "To Kill a Mockingbird",
        author: "Harper Lee",
        isbn: "978-0061120084",
        genre: "Fiction",
        year: 1960,
        publisher: "Harper Perennial",
        pages: 324,
        description: "A gripping, heart-wrenching tale of race and identity in the American South.",
        inStock: true,
        price: 14.99
    }
];

// Глобальный счетчик ID
let nextId = books.length + 1;

// Валидация данных книги
const validateBook = (book, isUpdate = false) => {
    const errors = [];

    if (!isUpdate || book.title !== undefined) {
        if (!book.title || book.title.trim().length < 1) {
            errors.push('Название книги обязательно и должно содержать хотя бы 1 символ');
        }
    }

    if (!isUpdate || book.author !== undefined) {
        if (!book.author || book.author.trim().length < 2) {
            errors.push('Автор книги обязателен и должен содержать хотя бы 2 символа');
        }
    }

    if (!isUpdate || book.isbn !== undefined) {
        if (!book.isbn || !/^(?:\d{10}|\d{13})$/.test(book.isbn.replace(/-/g, ''))) {
            errors.push('ISBN должен быть 10 или 13 цифр');
        }
    }

    if (book.year !== undefined && (book.year < 1000 || book.year > new Date().getFullYear())) {
        errors.push(`Год издания должен быть между 1000 и ${new Date().getFullYear()}`);
    }

    if (book.pages !== undefined && book.pages < 1) {
        errors.push('Количество страниц должно быть положительным числом');
    }

    if (book.price !== undefined && book.price < 0) {
        errors.push('Цена не может быть отрицательной');
    }

    return errors;
};

// Middleware для логирования
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// Middleware для поиска книги по ID
app.param('id', (req, res, next, id) => {
    const bookId = parseInt(id);
    
    if (isNaN(bookId)) {
        return res.status(400).json({
            error: 'Неверный формат ID',
            message: 'ID должен быть числом'
        });
    }

    const book = books.find(b => b.id === bookId);
    
    if (!book) {
        return res.status(404).json({
            error: 'Книга не найдена',
            message: `Книга с ID ${bookId} не существует`
        });
    }
    
    req.book = book;
    req.bookId = bookId;
    next();
});

// Задание 2: Реализация CRUD операций

// Часть A: GET endpoints

// GET /api/books - возвращает все книги с поддержкой фильтрации и пагинации
app.get('/api/books', (req, res) => {
    let filteredBooks = [...books];
    
    // Фильтрация по query-параметрам
    const { author, genre, year, inStock, search, minPrice, maxPrice } = req.query;
    
    if (author) {
        filteredBooks = filteredBooks.filter(book => 
            book.author.toLowerCase().includes(author.toLowerCase())
        );
    }
    
    if (genre) {
        filteredBooks = filteredBooks.filter(book => 
            book.genre.toLowerCase().includes(genre.toLowerCase())
        );
    }
    
    if (year) {
        filteredBooks = filteredBooks.filter(book => book.year === parseInt(year));
    }
    
    if (inStock !== undefined) {
        const inStockBool = inStock === 'true';
        filteredBooks = filteredBooks.filter(book => book.inStock === inStockBool);
    }
    
    if (search) {
        const searchLower = search.toLowerCase();
        filteredBooks = filteredBooks.filter(book =>
            book.title.toLowerCase().includes(searchLower) ||
            book.author.toLowerCase().includes(searchLower) ||
            book.description.toLowerCase().includes(searchLower)
        );
    }
    
    if (minPrice) {
        filteredBooks = filteredBooks.filter(book => book.price >= parseFloat(minPrice));
    }
    
    if (maxPrice) {
        filteredBooks = filteredBooks.filter(book => book.price <= parseFloat(maxPrice));
    }
    
    // Пагинация
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    
    const result = {
        total: filteredBooks.length,
        page,
        limit,
        totalPages: Math.ceil(filteredBooks.length / limit),
        books: filteredBooks.slice(startIndex, endIndex)
    };
    
    res.json(result);
});

// GET /api/books/:id - возвращает книгу по ID
app.get('/api/books/:id', (req, res) => {
    res.json(req.book);
});

// Часть B: POST endpoint

// POST /api/books - создание новой книги
app.post('/api/books', (req, res) => {
    const { title, author, isbn, genre, year, publisher, pages, description, price } = req.body;
    
    const newBook = {
        title,
        author,
        isbn,
        genre: genre || 'Unknown',
        year: year || new Date().getFullYear(),
        publisher: publisher || 'Unknown',
        pages: pages || 0,
        description: description || '',
        inStock: true,
        price: price || 0
    };
    
    // Валидация данных
    const errors = validateBook(newBook);
    if (errors.length > 0) {
        return res.status(400).json({
            error: 'Ошибка валидации',
            messages: errors
        });
    }
    
    // Проверка уникальности ISBN
    const existingBook = books.find(book => book.isbn === newBook.isbn);
    if (existingBook) {
        return res.status(409).json({
            error: 'Конфликт',
            message: 'Книга с таким ISBN уже существует'
        });
    }
    
    // Создание новой книги
    newBook.id = nextId++;
    books.push(newBook);
    
    res.status(201).json({
        message: 'Книга успешно создана',
        book: newBook
    });
});

// Часть C: PUT и PATCH endpoints

// PUT /api/books/:id - полное обновление книги
app.put('/api/books/:id', (req, res) => {
    const bookIndex = books.findIndex(b => b.id === req.bookId);
    const { title, author, isbn, genre, year, publisher, pages, description, inStock, price } = req.body;
    
    const updatedBook = {
        id: req.bookId,
        title,
        author,
        isbn,
        genre,
        year,
        publisher,
        pages,
        description,
        inStock,
        price
    };
    
    // Валидация данных
    const errors = validateBook(updatedBook);
    if (errors.length > 0) {
        return res.status(400).json({
            error: 'Ошибка валидации',
            messages: errors
        });
    }
    
    // Проверка уникальности ISBN (исключая текущую книгу)
    const isbnExists = books.some(book => book.isbn === updatedBook.isbn && book.id !== req.bookId);
    if (isbnExists) {
        return res.status(409).json({
            error: 'Конфликт',
            message: 'Книга с таким ISBN уже существует'
        });
    }
    
    books[bookIndex] = updatedBook;
    
    res.json({
        message: 'Книга полностью обновлена',
        book: updatedBook
    });
});

// PATCH /api/books/:id - частичное обновление книги
app.patch('/api/books/:id', (req, res) => {
    const bookIndex = books.findIndex(b => b.id === req.bookId);
    
    const updatedFields = { ...req.body };
    delete updatedFields.id; // Запрещаем изменение ID
    
    const updatedBook = {
        ...books[bookIndex],
        ...updatedFields
    };
    
    // Валидация только обновляемых полей
    const errors = validateBook(updatedFields, true);
    if (errors.length > 0) {
        return res.status(400).json({
            error: 'Ошибка валидации',
            messages: errors
        });
    }
    
    // Проверка уникальности ISBN (если обновляется)
    if (updatedFields.isbn) {
        const isbnExists = books.some(book => book.isbn === updatedFields.isbn && book.id !== req.bookId);
        if (isbnExists) {
            return res.status(409).json({
                error: 'Конфликт',
                message: 'Книга с таким ISBN уже существует'
            });
        }
    }
    
    books[bookIndex] = updatedBook;
    
    res.json({
        message: 'Книга частично обновлена',
        book: updatedBook
    });
});

// Часть D: DELETE endpoint

// DELETE /api/books/:id - удаление книги
app.delete('/api/books/:id', (req, res) => {
    const bookIndex = books.findIndex(b => b.id === req.bookId);
    const deletedBook = books.splice(bookIndex, 1)[0];
    
    res.json({
        message: 'Книга успешно удалена',
        book: deletedBook
    });
});

// Задание 3: Дополнительные функции

// GET /api/books/stats - статистика по книгам
app.get('/api/books/stats', (req, res) => {
    const stats = {
        totalBooks: books.length,
        totalInStock: books.filter(book => book.inStock).length,
        totalOutOfStock: books.filter(book => !book.inStock).length,
        genres: [...new Set(books.map(book => book.genre))],
        authors: [...new Set(books.map(book => book.author))],
        averagePrice: books.reduce((sum, book) => sum + book.price, 0) / books.length,
        oldestBook: books.reduce((oldest, book) => book.year < oldest.year ? book : oldest),
        newestBook: books.reduce((newest, book) => book.year > newest.year ? book : newest)
    };
    
    res.json(stats);
});

// GET /api/books/search - расширенный поиск
app.get('/api/books/search', (req, res) => {
    const { q } = req.query;
    
    if (!q) {
        return res.status(400).json({
            error: 'Параметр поиска обязателен',
            message: 'Используйте параметр q для поиска'
        });
    }
    
    const searchTerm = q.toLowerCase();
    const results = books.filter(book =>
        book.title.toLowerCase().includes(searchTerm) ||
        book.author.toLowerCase().includes(searchTerm) ||
        book.description.toLowerCase().includes(searchTerm) ||
        book.genre.toLowerCase().includes(searchTerm) ||
        book.publisher.toLowerCase().includes(searchTerm)
    );
    
    res.json({
        query: q,
        count: results.length,
        books: results
    });
});

// Корневой маршрут с документацией
app.get('/', (req, res) => {
    res.json({
        message: 'REST API для управления книгами',
        version: '1.0.0',
        endpoints: {
            'GET /api/books': 'Получить все книги (с фильтрацией и пагинацией)',
            'GET /api/books/:id': 'Получить книгу по ID',
            'POST /api/books': 'Создать новую книгу',
            'PUT /api/books/:id': 'Полное обновление книги',
            'PATCH /api/books/:id': 'Частичное обновление книги',
            'DELETE /api/books/:id': 'Удалить книгу',
            'GET /api/books/stats': 'Статистика по книгам',
            'GET /api/books/search': 'Расширенный поиск'
        },
        examples: {
            'Фильтрация': '/api/books?author=Orwell&genre=Dystopian',
            'Пагинация': '/api/books?page=1&limit=5',
            'Поиск': '/api/books/search?q=javascript'
        }
    });
});

// Обработка 404 для API маршрутов
app.use('/api/*', (req, res) => {
    res.status(404).json({
        error: 'Маршрут не найден',
        message: `Маршрут ${req.method} ${req.originalUrl} не существует`,
        availableEndpoints: [
            'GET /api/books',
            'GET /api/books/:id',
            'POST /api/books',
            'PUT /api/books/:id',
            'PATCH /api/books/:id',
            'DELETE /api/books/:id',
            'GET /api/books/stats',
            'GET /api/books/search'
        ]
    });
});

// Общая обработка 404
app.use('*', (req, res) => {
    res.status(404).json({
        error: 'Маршрут не найден',
        path: req.originalUrl
    });
});

// Централизованная обработка ошибок
app.use((err, req, res, next) => {
    console.error('Ошибка сервера:', err);
    
    res.status(500).json({
        error: 'Внутренняя ошибка сервера',
        message: process.env.NODE_ENV === 'development' ? err.message : 'Что-то пошло не так'
    });
});

app.listen(PORT, () => {
    console.log(`📚 REST API для книг запущен на порту ${PORT}`);
    console.log(`📍 Основной URL: http://localhost:${PORT}`);
    console.log(`📖 API документация: http://localhost:${PORT}/api/books`);
    console.log(`🔍 Пример поиска: http://localhost:${PORT}/api/books/search?q=javascript`);
});